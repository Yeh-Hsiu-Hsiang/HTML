$(function(){
    var containerEl = document.querySelector('.container');
    var mixer = mixitup(containerEl);
})